import { UserConfigInfoModel } from '@/common/model/userConfigInfo.model'

export default interface UserConfigInfoStateTypes {
  userConfigInfo: UserConfigInfoModel
}
