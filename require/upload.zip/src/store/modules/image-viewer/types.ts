export default interface ImageViewerStateTypes {
  imageViewer: any
}
