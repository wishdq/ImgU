export default interface UploadSettingsStateTypes {
  uploadSettings: {
    isSetMaxSize: boolean
    compressSize: number
  }
}
