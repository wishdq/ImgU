export default interface UploadAreaActiveStateTypes {
  uploadAreaActive: boolean
}
