import { registerSW } from 'virtual:pwa-register'

registerSW()
