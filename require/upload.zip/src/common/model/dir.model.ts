export enum DirModeEnum {
  autoDir = 'autoDir',
  newDir = 'newDir',
  rootDir = 'rootDir',
  reposDir = 'reposDir'
}
